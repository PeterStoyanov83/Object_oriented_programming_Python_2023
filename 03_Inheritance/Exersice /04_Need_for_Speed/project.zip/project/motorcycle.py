from project.vehicle import Vehicle


class Motorcycle(Vehicle):
    pass

